# Temporary research helper owned by #2195. Never include it in the candidate.
import os, subprocess
assert subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip() == '5f48dbe981554bbd5c9a0964385ae09292c22072'
#!/usr/bin/env python3
"""Apply the reviewed constructor-only resource-capability change to an exact source tree."""
from pathlib import Path
import re

ROOT = Path('.')
LIB = ROOT / 'crates/noon-render-wgpu/src/lib.rs'
RET = ROOT / 'crates/noon-render-wgpu/src/gpu/retained_text.rs'
MEGA = ROOT / 'crates/noon-render-wgpu/src/mega_mesh.rs'

def once(s, before, after):
    assert s.count(before) == 1, (before[:100], s.count(before))
    return s.replace(before, after)

def block_end(s, start):
    # Only used for simple Rust definition bodies (without braces in strings).
    depth = 0
    opening = s.index('{', start)
    for i in range(opening, len(s)):
        depth += (s[i] == '{') - (s[i] == '}')
        if depth == 0:
            return i + 1
    raise AssertionError('unclosed block')

s = LIB.read_text()
s = once(s, '#[derive(Debug, Default)]\npub struct FramePreparer {', '#[derive(Debug)]\npub struct FramePreparer {')
s = once(s, '    packed_path_buffer_limit: Option<u64>,', '    packed_path_buffer_limit: u64,')
start = s.index('pub struct FramePreparer {')
end = block_end(s, start)
fields = re.findall(r'^    (\w+): ', s[start:end], re.M)
assert len(fields) > 50 and 'packed_path_buffer_limit' in fields
ctor = '''    /// Create preparation state for one rendering target's buffer limit.
    ///
    /// The renderer/host supplies `device.limits().max_buffer_size` once during
    /// initialization. CPU-only tools and tests supply an explicit capability.
    /// Every full and incremental preparation applies this same limit; there
    /// is no uncapped default or per-frame device-specific entry point.
    /// Recreate this state together with device-bound resources after changing
    /// targets. Ordinary geometry still has its own allocation requirements.
    ///
    /// ```no_run
    /// # fn example(device: &wgpu::Device, frame: &noon_runtime::FrameState) {
    /// let mut preparer = noon_render_wgpu::FramePreparer::new(
    ///     device.limits().max_buffer_size,
    /// );
    /// let _ = preparer.prepare(frame);
    /// let _ = preparer.prepare_incremental(frame, &Default::default());
    /// # }
    /// ```
    ///
    /// Construction without an explicit capability is not supported:
    ///
    /// ```compile_fail
    /// let _ = noon_render_wgpu::FramePreparer::new();
    /// ```
    ///
    /// ```compile_fail
    /// let _: noon_render_wgpu::FramePreparer = Default::default();
    /// ```
    pub fn new(max_buffer_size: u64) -> Self {
        Self {
'''
ctor += ''.join(f'            {f}: ' + ('max_buffer_size' if f == 'packed_path_buffer_limit' else 'Default::default()') + ',\n' for f in fields)
ctor += '        }\n    }'
s = once(s, '    pub fn new() -> Self {\n        Self::default()\n    }', ctor)
s = once(s, 'pub(crate) fn for_individual_path_draws() -> Self', 'pub(crate) fn for_individual_path_draws(max_buffer_size: u64) -> Self')
s = once(s, 'pub(crate) fn for_mixed_retained_path_draws() -> Self', 'pub(crate) fn for_mixed_retained_path_draws(max_buffer_size: u64) -> Self')
# The only Self::default() constructors in this impl are now the two private modes.
a = s.index('    #[cfg(test)]\n    pub(crate) fn for_individual_path_draws')
b = s.index('    /// Install the actual renderer device limit', a)
region = s[a:b]
assert region.count('..Self::default()') == 2
s = s[:a] + region.replace('..Self::default()', '..Self::new(max_buffer_size)') + s[b:]
a = s.index('    /// Install the actual renderer device limit')
b = s.index("    pub fn prepare<'a>", a)
s = s[:a] + '    /// Prepare using the target capabilities established at construction.\n' + s[b:]
s = once(s, '''    /// This uses the previously installed cap, or no device cap before one
    /// is installed. Prefer `prepare_incremental_for_device` for GPU-bound frames.
    ///
''', '')
LIB.write_text(s)

s = RET.read_text()
s = once(s, '''    // Unit tests may lower the packed-only admission limit without shrinking
    // unrelated text, image or multisample readback buffers on the GPU device.
    #[cfg(test)]
    packed_path_test_limit: Option<u64>,
''', '')
s = once(s, 'impl Default for RetainedFramePreparer {\n    fn default() -> Self {', '''impl RetainedFramePreparer {
    /// Initialize retained preparation with the target's buffer capability.
    /// The host supplies this once along with renderer construction, not per frame.
    /// Reconstruct on device replacement; preparation never changes this limit.
    pub fn new(max_buffer_size: u64) -> Self {''')
s = once(s, '''            geometry: FramePreparer::for_mixed_retained_path_draws(),
            #[cfg(test)]
            packed_path_test_limit: None,''', '            geometry: FramePreparer::for_mixed_retained_path_draws(max_buffer_size),')
s = once(s, '    pub fn new() -> Self {\n        Self::default()\n    }\n\n', '')
needle = '''        let mut geometry = FramePreparer::for_mixed_retained_path_draws();
        geometry.set_packed_path_buffer_limit(device.limits().max_buffer_size);'''
assert s.count(needle) == 2
s = s.replace(needle, '''        let mut geometry = FramePreparer::for_mixed_retained_path_draws(
            self.geometry.packed_path_buffer_limit,
        );''')
s = once(s, 'let mut replacement = Self::with_outline_cache_limits(self.outline_cache_limits());', '''let mut replacement = Self::with_outline_cache_limits(
            self.geometry.packed_path_buffer_limit,
            self.outline_cache_limits(),
        );''')
s = once(s, '''    pub fn with_outline_cache_limits(limits: GlyphOutlineCacheLimits) -> Self {
        let mut preparer = Self::default();''', '''    pub fn with_outline_cache_limits(
        max_buffer_size: u64,
        limits: GlyphOutlineCacheLimits,
    ) -> Self {
        let mut preparer = Self::new(max_buffer_size);''')
s = once(s, '''        let packed_limit = device.limits().max_buffer_size;
        #[cfg(test)]
        let packed_limit = packed_limit.min(self.packed_path_test_limit.unwrap_or(u64::MAX));
        self.geometry.set_packed_path_buffer_limit(packed_limit);
''', '')
# Raster-budget test now constructs its restricted preparation state explicitly.
s = once(s, 'limited_preparer.packed_path_test_limit = Some(limited_bytes as u64);', 'limited_preparer = RetainedFramePreparer::new(limited_bytes as u64);\n                    limited_preparer.set_painter_order(&painter_order);')
RET.write_text(s)
print('Changed constructor and retained reset ownership. Caller migration follows.')

s = MEGA.read_text()
s = once(s, 'self.packed_path_buffer_limit.unwrap_or(u64::MAX)', 'self.packed_path_buffer_limit')
s = once(s, '''        let mut preparer = FramePreparer::for_mixed_retained_path_draws();
        preparer.set_packed_path_buffer_limit(65_536);''', '        let preparer = FramePreparer::for_mixed_retained_path_draws(65_536);')
s = once(s, '        preparer.set_packed_path_buffer_limit(255);', '        let preparer = FramePreparer::for_mixed_retained_path_draws(255);')
# One explicit capability parameter for the shared preload fixture.
s = once(s, '''    fn preloaded_prefix_fixture(
        count: usize,
''', '''    fn preloaded_prefix_fixture(
        count: usize,
        max_buffer_size: u64,
''')
fi = s.index('    fn preloaded_prefix_fixture(')
fe = block_end(s, fi)
fixture = s[fi:fe]
fixture = once(fixture, 'FramePreparer::for_mixed_retained_path_draws()', 'FramePreparer::for_mixed_retained_path_draws(max_buffer_size)')
s = s[:fi] + fixture + s[fe:]
s = re.sub(r'preloaded_prefix_fixture\(([^()\n,:]+)\)', r'preloaded_prefix_fixture(\1, wgpu::Limits::default().max_buffer_size)', s)

hs = s.index('    fn high_address_preload_falls_back_on_real_limited_device()')
he = block_end(s, hs)
h = s[hs:he]
device = '''        let (device, queue) = wgpu::Device::noop(&wgpu::DeviceDescriptor {
            required_limits: wgpu::Limits {
                max_buffer_size: LIMIT as u64,
                ..Default::default()
            },
            ..Default::default()
        });
        assert_eq!(device.limits().max_buffer_size, LIMIT as u64);
'''
h = once(h, device, '')
anchor = '        let (mut preparer, mut frame, rows, ranges) = preloaded_prefix_fixture(count, wgpu::Limits::default().max_buffer_size);'
h = once(h, anchor, device + '''        let (mut preparer, mut frame, rows, ranges) =
            preloaded_prefix_fixture(count, device.limits().max_buffer_size);''')
h = once(h, '        let unbounded = preparer.prepare(&frame);', '''        // An explicit larger-capability control proves this scene would need
        // oversized packed attributes. Never upload this control on the small device.
        let mut control = preloaded_prefix_fixture(count, u64::MAX).0;
        let unbounded = control.prepare(&frame);''')
h = once(h, '''        // Never upload the unbounded witness: it is a deliberate negative.
        // The public device-aware entry point installs admission before packing.
        let bounded = preparer.prepare_for_device(&device, &frame);''', '''        // Normal preparation already owns the device's limit from construction.
        let bounded = preparer.prepare(&frame);''')
h = once(h, '''        // Supplying the same device must not invalidate an otherwise clean frame.
        let clean = preparer.prepare_incremental_for_device(&device, &frame, &Default::default());''', '''        // A clean frame does not inspect a device or mutate target capabilities.
        let clean = preparer.prepare_incremental(&frame, &Default::default());''')
h = once(h, '''        // An actual larger-limit device re-admits packing even with an empty
        // delta. No semantic edit or private setter is needed by the caller.''', '''        // Device replacement constructs a new renderer/preparer pair. Target
        // capabilities never become mutable history of per-frame calls.''')
h = once(h, '''        let recovered =
            preparer.prepare_incremental_for_device(&larger_device, &frame, &Default::default());''', '''        let mut larger_preparer =
            preloaded_prefix_fixture(count, larger_device.limits().max_buffer_size).0;
        let recovered = larger_preparer.prepare_incremental(&frame, &Default::default());''')
h = once(h, '''        // Returning to the smaller cap must fall back before the next upload.
        let bounded_again =
            preparer.prepare_incremental_for_device(&device, &frame, &Default::default());''', '''        // The original target remains constrained; the larger target's work
        // cannot change its admission or dirty its previously clean frame.
        let bounded_again = preparer.prepare_incremental(&frame, &Default::default());
        assert_eq!(bounded_again.stats.full_rebuilds, 0);''')
s = s[:hs] + h + s[he:]
ss = s.index('    fn structural_append_uses_local_individual_fallback_at_packed_limit()')
se = block_end(s, ss)
h = s[ss:se]
h = once(h, 'let (mut preparer, mut frame, rows, ranges) = preloaded_prefix_fixture(32, wgpu::Limits::default().max_buffer_size);', 'let (_, mut frame, rows, ranges) = preloaded_prefix_fixture(32, wgpu::Limits::default().max_buffer_size);')
h = once(h, '        preparer.set_packed_path_buffer_limit(limit as u64);', '        let mut preparer = preloaded_prefix_fixture(32, limit as u64).0;')
h = once(h, '''        preparer.set_packed_path_buffer_limit(u64::MAX);
        let recovered = preparer.prepare(&frame);''', '''        let mut larger_preparer = preloaded_prefix_fixture(32, u64::MAX).0;
        let recovered = larger_preparer.prepare(&frame);''')
s = s[:ss] + h + s[se:]
MEGA.write_text(s)

p = ROOT / 'crates/noon-render-wgpu/src/path_residency.rs'
s = p.read_text()
s = once(s, '''        // A rejected optional packed allocation does not retroactively free
        // already retained CPU storage. Ordinary source paths remain present.
        preparer.set_packed_path_buffer_limit(255);
        let fallback = preparer.prepare(&frame);
        assert_eq!(fallback.stats.mega_path_count, 0);
        assert_eq!(fallback.paths.len(), COUNT);
        assert_eq!(preparer.packed_path_cpu_buffer_bytes(), (0, baseline.1));
        preparer.set_packed_path_buffer_limit(u64::MAX);
        assert_eq!(preparer.prepare(&frame).stats.mega_path_count, COUNT);
        assert_eq!(preparer.packed_path_cpu_buffer_bytes(), baseline);''', '''        // A separate constrained target rejects optional packing at its first
        // preparation; it never mutates or releases this target's retained data.
        let mut constrained = FramePreparer::for_mixed_retained_path_draws(255);
        let fallback = constrained.prepare(&frame);
        assert_eq!(fallback.stats.mega_path_count, 0);
        assert_eq!(fallback.paths.len(), COUNT);
        assert_eq!(constrained.packed_path_cpu_buffer_bytes(), (0, 0));
        assert_eq!(preparer.packed_path_cpu_buffer_bytes(), baseline);
        let clean = preparer.prepare_incremental(&frame, &FrameChanges::default());
        assert_eq!(clean.stats.full_rebuilds, 0);
        assert!(clean.mega_path_instance_dirty_ranges.is_empty());''')
p.write_text(s)
print('Reworked reduced-limit and accounting tests around immutable constructor capabilities.')

# Explicit production wiring and mechanical test migration.
from pathlib import Path
import re, json
ROOT=Path('.')

def once(p,b,a):
 s=p.read_text(); assert s.count(b)==1,(str(p),b[:120],s.count(b));p.write_text(s.replace(b,a))

# Create capabilities before moving the device into its owning host struct.
for path,anchor in [
 ('crates/noon-native/src/lib.rs','        let text_state = renderer.create_retained_text_state(&device, &queue);'),
 ('crates/noon-export/src/gpu.rs','        fault.check()?;\n        Ok(Self {'),
 ('crates/noon/tests/raster_support/mod.rs','        Self {\n            device,\n            queue,\n            renderer,'),
 ('crates/noon-render-wgpu/src/gpu/retained_text/glow_publication/tests.rs','        Self {\n            device,\n            queue,\n            renderer,'),
]:
 p=ROOT/path
 if path.endswith('noon-native/src/lib.rs'):
  after=anchor+'\n        let preparer = RetainedFramePreparer::new(device.limits().max_buffer_size);'
 elif path.endswith('noon-export/src/gpu.rs'):
  after='        fault.check()?;\n        let preparer = RetainedFramePreparer::new(device.limits().max_buffer_size);\n        Ok(Self {'
 else:
  after='        let preparer = RetainedFramePreparer::new(device.limits().max_buffer_size);\n'+anchor
 once(p,anchor,after)
 once(p,'preparer: RetainedFramePreparer::new(),','preparer,')

p=ROOT/'crates/noon-web/src/execution_canvas.rs'
s=p.read_text()
assert s.count('self.direct_preparer = RetainedFramePreparer::new();')==2
s=s.replace('self.direct_preparer = RetainedFramePreparer::new();','self.direct_preparer = RetainedFramePreparer::new(self.device.limits().max_buffer_size);')
anchor='''            let webgl_context_lifecycle =
                crate::webgl_context_lifecycle::WebGlContextLifecycle::install(&canvas, backend)?;

            let mut result = Self {'''
assert s.count(anchor)==1
s=s.replace(anchor,'''            let webgl_context_lifecycle =
                crate::webgl_context_lifecycle::WebGlContextLifecycle::install(&canvas, backend)?;
            let direct_preparer = RetainedFramePreparer::new(device.limits().max_buffer_size);

            let mut result = Self {''')
assert s.count('direct_preparer: RetainedFramePreparer::new(),')==1
s=s.replace('direct_preparer: RetainedFramePreparer::new(),','direct_preparer,')
p.write_text(s)
p=ROOT/'crates/noon-web/src/retained_execution_canvas.rs'
once(p,'let mut preparer = RetainedFramePreparer::new();','let mut preparer = RetainedFramePreparer::new(device.limits().max_buffer_size);')

# Remaining calls are CPU fixtures/benchmarks or GPU tests. Prefer actual
# device capabilities when the current function already has its device;
# otherwise declare the synthetic standard target explicitly.
pattern=re.compile(r'\b((?:Retained)?FramePreparer)::(new|default|for_individual_path_draws|for_mixed_retained_path_draws)\(\)')
report=[]
for p in ROOT.rglob('*.rs'):
 s=p.read_text(); replacements=[]
 for m in pattern.finditer(s):
  line=s[s.rfind('\n',0,m.start())+1:m.start()]
  if line.lstrip().startswith('///'):continue # deliberate compile-fail examples
  prefix=s[:m.start()]
  fs=prefix.rfind('fn ')
  context=prefix[fs:]
  gpu_device=bool(re.search(r'\bdevice\s*:\s*&(?:\s*\'\w+\s+)?wgpu::Device',context) or re.search(r'let\s+\([^;]*\bdevice\b[^;]*\)\s*=\s*[^;]+;',context,re.S))
  cap='device.limits().max_buffer_size' if gpu_device else 'wgpu::Limits::default().max_buffer_size'
  method='new' if m[2]=='default' else m[2]
  replacement=f'{m[1]}::{method}({cap})'
  report.append({'path':str(p),'line':prefix.count('\n')+1,'capability':cap,'function':context.split('\n')[0][:100]})
  replacements.append((m.start(),m.end(),replacement))
 for a,b,t in reversed(replacements):s=s[:a]+t+s[b:]
 if replacements:p.write_text(s)
(Path(os.environ['PROOF_DIR']) / 'migrated-callers.json').write_text(json.dumps(report,indent=2))
print('Migrated remaining',len(report),'test/benchmark calls.')
print('GPU device inferred:',sum(x['capability'].startswith('device.') for x in report))

# Strengthen lifecycle and API invariants.
from pathlib import Path
import re,json
p=Path('crates/noon-render-wgpu/src/gpu/retained_text.rs')
s=p.read_text()
b='''    /// Reconstruct on device replacement; preparation never changes this limit.
    pub fn new(max_buffer_size: u64) -> Self {'''
a='''    /// Reconstruct on device replacement; preparation never changes this limit.
    ///
    /// Uncapped construction is not part of this API:
    ///
    /// ```compile_fail
    /// let _ = noon_render_wgpu::RetainedFramePreparer::new();
    /// ```
    ///
    /// ```compile_fail
    /// let _: noon_render_wgpu::RetainedFramePreparer = Default::default();
    /// ```
    pub fn new(max_buffer_size: u64) -> Self {'''
assert s.count(b)==1;s=s.replace(b,a)
# Test the existing preload/compaction transaction preserves an explicitly
# narrower initial target, not the larger currently passed GPU's limit.
a=s.index('    fn encoded_frame_keeps_retired_image_and_compacted_paths_alive_until_submit()')
z=s.index('    #[test]',a+10)
f=s[a:z]
b='        let mut retained = RetainedFramePreparer::new(device.limits().max_buffer_size);'
n='''        let target_buffer_limit = device.limits().max_buffer_size / 2;
        let mut retained = RetainedFramePreparer::new(target_buffer_limit);'''
assert f.count(b)==1;f=f.replace(b,n)
b='''        retained
            .preload_path_meshes(&device, &queue, &mut renderer, &requests)
            .unwrap();'''
n=b+'''\n        assert_eq!(retained.geometry.packed_path_buffer_limit, target_buffer_limit);'''
assert f.count(b)==1;f=f.replace(b,n)
b='''        queue.submit([]);
        assert!(compacted.upload.bytes_uploaded > 0);'''
n='''        queue.submit([]);
        assert_eq!(retained.geometry.packed_path_buffer_limit, target_buffer_limit);
        assert!(compacted.upload.bytes_uploaded > 0);'''
assert f.count(b)==1;f=f.replace(b,n)
b='''            assert_eq!(compacted.upload.buffer_reallocations, 5);
            assert_eq!(renderer.geometry_buffer_residency().packed_path_bytes(), 8);'''
n='''            assert_eq!(compacted.upload.buffer_reallocations, 5);
            assert_eq!(retained.geometry.packed_path_buffer_limit, target_buffer_limit);
            assert_eq!(renderer.geometry_buffer_residency().packed_path_bytes(), 8);'''
assert f.count(b)==1;f=f.replace(b,n)
s=s[:a]+f+s[z:];p.write_text(s)

# Source guards supplement executable compilation and behavior checks.
for p in Path('crates').rglob('*.rs'):
 s=p.read_text()
 assert not re.search(r'prepare(?:_incremental)?_for_device|set_packed_path_buffer_limit|packed_path_test_limit',s),str(p)
 for m in re.finditer(r'\b(?:Retained)?FramePreparer::(?:new|default)\(\)',s):
  line=s[s.rfind('\n',0,m.start())+1:m.start()]
  assert line.lstrip().startswith('///'), (str(p),m[0])
print('Removed old entry points and mutable cap setter; no executable uncapped constructors remain.')
